function [p] = reset_p(p, max_ind)

% Unpacking max_ind:
x2 = double(max_ind(1)) * 4;
y2 = double(max_ind(2)) * 4; % go from fine 4x8 matrix to 16x32 matrix and half the index (place in mid of tile)

x1 = x2-3;
y1 = y2-3;

% overwriting matrix probabilities with exact location
p(x1:x2, y1:y2) = 0.95 * ones(4,4);

end