function [p, heading] = Localize_2D_move(p, M, m_m, heading);
% provide measurements and movements
%movement update

% Using Sevket's Version Below
[p, heading] = move_sevketversion(p, M, heading, m_m);
end
