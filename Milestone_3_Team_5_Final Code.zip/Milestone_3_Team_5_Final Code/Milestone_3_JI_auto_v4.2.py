import socket
import struct
from threading import Thread
import _thread
import serial
from datetime import datetime
import time
import math
import pygame
import matlab.engine
import vlc
#from pydub import AudioSegment
#from pydub.playback import play

### Simulate or Run a Rover ### ------------------------------------------------------------------------------------------------------------------------------------------------------------
SIMULATE = False

if SIMULATE == True:
    tempTimeOut = 1
elif SIMULATE == False:
    tempTimeOut = 1

# Initialize MATLAB Connection and Engine
names = matlab.engine.find_matlab()     # Line for finding available shared sessions
print(names)                            # Debug to check shared session
eng = matlab.engine.connect_matlab()    # Line for connecting to shared MATLAB sessions

def Manual_Input():
    try:
        data = input("Please input a command: ")
        return data
    except:
        print("Invalid Input")
        
def robo_move(data):
    try:
        transmit(data)
        # Loop for waiting until code is executed
        rxString = ""
        time.sleep(0.5)
        while rxString != math.inf and rxString != "$" and rxString != "#":
            rxString = responses[0]
            time.sleep(0.5)
    except:
        print("Invalid Input")

def angle_correction():
    # Parameters 
    sensRecord = []
    sensRecord = sensors(sensRecord) #get readings for all sensors
    print(sensRecord)


    if sensRecord[1] > 5 or sensRecord[2]> 5: #side sensor limits
        return('Cannot align in this area')

    if sensRecord[1]<sensRecord[2]:
        rotateside='left'
    else:
        rotateside='right'


    if rotateside=='left':
        if abs(sensRecord[1]-sensRecord[2])<0.5:
            return('Already Aligned')
        else:
            transmit('r0-5')

    elif rotateside=='right':
        if abs(sensRecord[1]-sensRecord[2])<0.5:
            return('Already Aligned')
        else:
            transmit('r0--5')
            
    '''if SIMULATE == False:
        SideSensorThreshold = 2
        DiagSensorThreshold = 3
    else:
        SideSensorThreshold = 1.5
        DiagSensorThreshold = 3
    sensRecord = []
    sensRecord = sensors(sensRecord) #get readings for all sensors
    print(sensRecord)'''
    
    
    
    '''while 0<sensRecord[4]<DiagSensorThreshold:
            sensRecord = sensors(sensRecord)
            transmit('r0-4')
    while 0<sensRecord[5]<DiagSensorThreshold:
            sensRecord = sensors(sensRecord)
            transmit('r0--4')'''

    #if abs(2.2-sensRecord[0])>0.4 and 0<sensRecord[0]<6:
    if abs(2.2-sensRecord[0])>0.2 and 0<sensRecord[0]<8:
        if sensRecord[0]>2.2:
            movement_correct=sensRecord[0]-2.2
            movement = 'w0-' + str(movement_correct)
            transmit(movement)
        else:
            movement_correct=2.2-sensRecord[0]
            movement = 'w0--' + str(movement_correct)
            transmit(movement)
            
    ''' if 0<sensRecord[1]<SideSensorThreshold:
            transmit('r0-6')
    elif 0<sensRecord[2]<SideSensorThreshold:
            transmit('r0--6')'''

def Pre_Local_Robo_Transmit(drive):
    # Drive: True/False, robot drives or not 

    #sensRecord = []         
    #sensRecord = sensors(sensRecord)                         # Call Robot for Sensor Data
    #print(sensRecord)                           # Debug - Array of Sensor Data 
    #tile_state = Ultra_to_Tile(sensRecord)      # Translate raw sensor readings into tile state
    
    # Parameters (inches)
    min_tol = 0.2
    max_tol = 5
    
    # Parameters for 1 tile space checker(inches)
    min_dis = 12
    max_dis = 16

    # Move executors and holders
    data = 'blank'

    # Subfunction to check what walls around the robot are ~12 inches away
    def wallDis1Check(reading):
        if (reading >= min_dis) and (reading <= max_dis):
            return 1
        else:
            return 0
        
    # Subfunction to check state based on tolerance parameters
    def closeWallCheck(reading):
        if (reading >= min_tol) and (reading <= max_tol):
            return 1
        else:
            return 0

    # subfunction to find and position robot to have right sensor register 1 tile position of distance (Specific for what to do in Tile 1 and Tile 0)
    def rightTurnFinder(execute):
        execute = 'blank'
        for i in range(0, len(courseCheck), 1):
                if courseCheck[i] == 1 and i != 1:
                    courseSet = (i - 1)* 90
                    execute = 'r0-'+str(courseSet)
        if wallCheck[0] == 0 and execute == 'blank':
            execute = 'w0-12'
        return execute

    # subfunction to find and position robot to find open space and change heading for open space. Finds heading changes and forward movements
    def headingFinder(execute):
        execute = 'blank'
        if wallCheck[1] == 0 and execute == 'blank':
            execute = 'r0-90'
        elif wallCheck[3] == 0 and execute == 'blank':
            execute = 'r0--90'
        elif wallCheck[2] == 0 and execute == 'blank':
            execute = 'r0-180'
        if wallCheck[0] == 0 and execute == 'blank':    # This is a seperate if statement to overwrite angle/heading changes that aren't needed. Avoids infinite loops
            execute = 'w0-12'
        return execute
        
    # Autonomous logic Loop
    while True:
        try:
            sensMoveRecord = []
            sensMoveRecord = sensors(sensMoveRecord)     # sensor call to determine possible movements
            tile_state = Ultra_to_Tile(sensMoveRecord)      # Translate raw sensor readings into tile state
            
            # Course Check - Array That Holds 'sub-discretized state' of 12" tiles from sensor readings, values of 0 and 1, 
                # [front, Right, Back, left]
            courseCheck = [wallDis1Check(sensMoveRecord[0]), wallDis1Check(sensMoveRecord[2]), wallDis1Check(sensMoveRecord[3]), wallDis1Check(sensMoveRecord[1])] # rearranges data to read sensor data clockwise starting from front sensor for tile space distance of 1

            wallCheck = [closeWallCheck(sensMoveRecord[0]), closeWallCheck(sensMoveRecord[2]), closeWallCheck(sensMoveRecord[3]), closeWallCheck(sensMoveRecord[1])] # rearranges data to read sensor data clockwise starting from front sensor immediate walls
            
            # Commands based on what Type of Tile Robot is in. 

            # Case 1 - 1 wall in tile: 
            if tile_state == 1:     # movement condition for tile value 1 - Takes sensor readings, and orients itself to have the right sensor read 1 tile space and hold forward command to execute afterwards. Also needs to check if arrived at L/Z   
                # Checks if robot is in LZ, if not, continues travel logic to loading zone
                if (courseCheck[0] + courseCheck[3]) != 2 and (courseCheck[0] + courseCheck[1]) != 2 and (courseCheck[2] + courseCheck[3]) != 2 and (courseCheck[2] + courseCheck[1]) != 2:  # checks to see if robot has arrived at Loading Zone
                    data = rightTurnFinder(data)
                
                else:    
                    # hardcoded method to get the robot to drive through the loading zone
                    print("Arrived at Loading Zone! Continuing movement for localization")
                    if wallCheck[0] == 0:
                        data = 'w0-12' 

            # Case 2: - Dead end, 3 walls around tile. 
            elif tile_state == 3:   # movement condition for tile value 3 - Checks to see if robot has returned, will send closing line to stop. Otherwise, prompts robot to leave for open space
                data = headingFinder(data)

            # Case 3: Open space   
            elif tile_state == 0:   # movement condition for tile value 0 - Ensures robot is moving towards L/Z - leftwards
                data = rightTurnFinder(data)
            
            # Case 4: x2 Parallel walls
            elif tile_state == 5:   # movement condition for tile value 5 - Ensures robot is moving forwards or finds heading to follow
                data = headingFinder(data) # orients robot towards an open direction if not done so already
                if data == "r0-180":    # prevents infinite loop of forcing robot to move 180 degrees
                    data = 'w0-12'
            
            # Case 5: x2 Walls in a corner
            elif tile_state == 2:     # movement condition for tile value 2 - ensures robot is moving towards open space
                if wallCheck[0] == 0: # checks to see if robot is oriented towards opening
                    data = 'w0-12'
                else:
                    data = headingFinder(data) # orients robot towards an open direction if not done so already      
            
            transmit(data)
            time.sleep(tempTimeOut)     # buffering time
            break                       # Exits loop
        except:
            if drive == True:
                print("Stopping code")
            else:
                print("bad input")
                data = 'r0-90'
                transmit(data)
                #robot_move = orthog_filter(data)    # blank execute command to clear system (NEED TO FIND A WAY TO INPUT A BLANK COMMAND TO RESTART CODE) ***************************************************************************************************
                time.sleep(tempTimeOut)     # buffering time
                break   


    # Code to check feedback when movement is done.             
    rxString = ""
    time.sleep(0.5)

    while rxString != math.inf and rxString != "$" and rxString != "#":
        #rxString = receive()
        rxString = responses[0]    # OLD CODE BEFORE IAN'S NEW BLUETOOTH CODE ****************************************************************************************************************************************
        time.sleep(0.5)

    return data

def Localize_Move_n_Sense(p, heading, sensor, fig, cmd, max_indx):
    # p - MATLAB probability Matrix
    # heading - heading of the robot, updates with time
    # fig - integer - specify MATLAb figure
    # cmd - movement or rotation command

    # Default State for condition variable
    cn = 1

    # 1) Update probability matrix with Movement
    cmd = orthog_filter(cmd)
    p, heading = eng.Localize_2D_move(p, matrix_mask, cmd, heading, nargout=2)

    # 2) Update probability matrix with Sensor readings
    tile_state = Ultra_to_Tile(sensor)     
    p, rob_x, rob_y, max_p = eng.Localize_2D_sense(p, ultra_world, matrix_mask, tile_state, fig, nargout=4)     # Updating Graph and localization probability

    # Rob_x and rob_y are the indices of the max probability in P
    rob_x = int(rob_x)
    rob_y = int(rob_y) 

    # Pull Max Indices from Last Iteration
    rob_xn_1 = max_indx[0]
    rob_yn_1 = max_indx[1]

    # If i crosses minimum threshold of Localization Iterations
    if i >= 3:
        delta_x = abs(rob_x - rob_xn_1)     
        delta_y = abs(rob_y - rob_yn_1)
        if delta_x > 1 or delta_y > 1:      # If the abs difference is greater than 1 - heading jumps, rule it out. 
            cn = 0
            return p, heading, cn, max_indx

    max_indx = [rob_x, rob_y]           # Overwrite History of Matrix Indexing
    print("debug - max index: ", max_indx)
    return p, heading, cn, max_indx

def LZ_Move_n_Sense(p, heading, fig, cmd, lm):
    # p - MATLAB probability Matrix
    # heading - heading of the robot, updates with time
    # fig - integer - specify MATLAb figure
    # cmd - movement or rotation command

    # 2) Update probability matrix with Movement
    cmd, lm = orthog_filter_postLocal(cmd, lm)  # New Localization done
    p, heading = eng.Localize_2D_move(p, matrix_mask, cmd, heading, nargout=2)

    # 3) Update probability matrix with More Sensor readings
    sensor = []
    sensor = sensors(sensor)                        # Update Sensor Readings
    tile_state = Ultra_to_Tile(sensor)     
    p, rob_x, rob_y, max_p = eng.Localize_2D_sense(p, ultra_world, matrix_mask, tile_state, fig, nargout=4)     # Updating Graph and localization probability

    # Rob_x and rob_y are the indices of the max probability in P
    rob_x = int(rob_x)
    rob_y = int(rob_y) 
    max_indx = [rob_x, rob_y]

    return p, heading, max_indx, lm

def orthog_filter(text):
    # Based on movement commands, output either w, a, s, or d into the matrix 
    # Assumptions: orthogonal angles are either +/-90 degrees, +/- 180 deg, or 0 deg
    text = text.split('-', 1)       # Must specify we're splitting once to retain negative states
    angle = int(text[1])            # Extract angle
    if text[0] == 'w0':
        if text[1] == '3':
            txt_cmd = 'w3'
        elif text[1] == '6':
            txt_cmd =  'w6'
        elif text[1] == '12':
            txt_cmd =  'w12'               
    # Case 1 - Moving Forward (w)
        #print("driving forward")
    elif text[0] == 'r0':
        if abs(angle)== 90:
            if angle > 0:
                txt_cmd =  'd'          # Case 2 - Rotating 90 deg Right (d)
                #print('right turn, "d"')
            elif angle < 0:
                txt_cmd =  'a'          # Case 3 - Rotating 90 deg Left (a)
                #print('left turn, "a"')
        elif abs(angle)== 180:
            txt_cmd =  's'              # Case 4 - Rotating 180 deg (s)
    return txt_cmd

def orthog_filter_postLocal(text, last_move):
    # Based on movement commands, output either w, a, s, or d into the matrix 
    # Assumptions: orthogonal angles are either +/-90 degrees, +/- 180 deg, or 0 deg
    text = text.split('-', 1)       # Must specify we're splitting once to retain negative states
    angle = int(text[1])            # Extract angle
    if text[0] == 'w0':
        if text[1] == '3':
            txt_cmd = 'w3'
        elif text[1] == '6':
            txt_cmd =  'w6'
        elif (text[1] == '12') and (last_move == 'r0'):     # Special offset Case 
            txt_cmd =  'w9'                                 # Feed slightly smaller value to avoid drift
        elif text[1] == '12':
            txt_cmd =  'w12'  
        elif text[1] == '-12':
            txt_cmd = '-w12' 
        last_move = 'w0'             
    # Case 1 - Moving Forward (w)
        #print("driving forward")
    elif text[0] == 'r0':
        if abs(angle)== 90:
            if angle > 0:
                txt_cmd =  'd'          # Case 2 - Rotating 90 deg Right (d)
                #print('right turn, "d"')
            elif angle < 0:
                txt_cmd =  'a'          # Case 3 - Rotating 90 deg Left (a)
                #print('left turn, "a"')
        elif abs(angle)== 180:
            txt_cmd =  's'              # Case 4 - Rotating 180 deg (s)
        last_move = 'r0'

    return txt_cmd, last_move

# Write function to take sensor readings and output a tile state (0, 1, 2, 3, 5)
def Ultra_to_Tile(sensor_array):
    '''
    11/14/2023:
    Ideated /partially coded on the GO Train/Sub
    Finished and tested at a Five Guys Burgers and Fries with Fries in Mouth

    - Code takes in first 4 elements of array as u0, u1, u2, and u3 as front, back, left, and right respectively
    - Sub function sen_check "sub discretizes" the readings as 1 and 0, w/ 1 outputted if the robot detects a wall
    - Main code conditional statements work from math

    6:54 pm - update:
    - Original sensor order mismatched
    - Corrected is front, left, right, back
    '''
    # Parameters (inches)
    min_tol = 0
    max_tol = 5
    # Subfunction to check state based on tolerance parameters
    def sen_check(reading):
        if (reading >= min_tol) and (reading <= max_tol):
            return 1
        else:
            return 0
    #print(sensor_array)
    # Take Sensor Array and Splice through 0th element to 3rd element in array wwhile checking state
    [u0_f, u2_l, u3_r, u1_b] = [sen_check(sensor_array[0]), sen_check(sensor_array[1]), sen_check(sensor_array[2]), sen_check(sensor_array[3])]

    # Way to implemented guarded clause?

    # Tile State 0
    if u0_f + u1_b + u2_l + u3_r == 0:
        return 0

    # Tile State 1
    elif u0_f + u1_b + u2_l + u3_r == 1:
        return 1
    
    # Tile State 2/5
    elif u0_f + u1_b + u2_l + u3_r == 2:
        # Tile State 5 - Parallel Checks in if statement via sum of corners
        if u0_f + u2_l == 1 and u1_b + u3_r == 1 and u0_f + u3_r == 1 and u1_b + u2_l == 1:
            return 5
        else:
            return 2
    
    # Tile State 3
    elif u0_f + u1_b + u2_l + u3_r == 3:
        return 3

    return tile

def findBlock(index):      # FUNCTION FOR FINDING BLOCK -------------------------------------------------------------------------------------
    blockRetrieved = False
    
    def executeSequence(instructions):
        blockRetrieved = False
        for command in instructions:
            time.sleep(0.5)
            transmit(command)
            if command == 'cls' or command == 'opn':
                time.sleep(1)
            elif command == 'b0':
                time.sleep(2)
                
                rxString = responses[0]
                while rxString == math.inf or rxString == "$" or rxString == "#":
                    #rxString = receive()
                    rxString = responses[0]    # OLD CODE BEFORE IAN'S NEW BLUETOOTH CODE ****************************************************************************************************************************************
                    time.sleep(0.5)
                print(rxString)
                if (round(float(rxString),1) < 1.5):
                    blockRetrieved = True
                else:
                    blockRetrieved = False
            else:
                rxString = ""
                time.sleep(0.5)
                iter = 0
                while rxString != math.inf and rxString != "$" and rxString != "#" and iter < 10:
                    #rxString = receive()
                    rxString = responses[0]    # OLD CODE BEFORE IAN'S NEW BLUETOOTH CODE ****************************************************************************************************************************************
                    time.sleep(0.5)
                    iter = iter + 1
        print("BLOCK SENSED: " + str(blockRetrieved))
        return blockRetrieved
    
    
    top_entrance = index == [1,3] #true if top entrance
    
    eating_sequence = ['cls','opn','cls','opn','cls','b0','w0-2']       # CHANGED TO TRY LOOK FOR BLOCK WHEN ARMS ARE CLOSED
    #eating_sequence = ['cls','opn','cls','opn','cls','opn','b0','cls','w0-2']
    col_sweep_sequence = ['w0-6','w0--6','opn','w0-10']
    
    if top_entrance:
        next_column_sequence = ['w0--12','r0--90','w0-6','r0-90']
    else:
        next_column_sequence = ['w0--12','r0-90','w0-6','r0--90']
    
    executeSequence(['opn','w0-12'])
    if not SIMULATE: 
        angle_correction()
    executeSequence(['w0-10'])
    player = vlc.MediaPlayer("C:/Users/isaac/Downloads/Robot Sounds/Robot Grabbing.wav")
    player.play()
    time.sleep(0.5)
    blockRetrieved = executeSequence(eating_sequence)
    if blockRetrieved:
        if top_entrance:
            executeSequence(['r0--90'])
        else:
            executeSequence(['r0-180'])
        executeSequence(['w0-12','w0-12'])
        angle_correction()
        return
    
    if top_entrance:
        executeSequence(['r0--90'])
    else:
        executeSequence(['r0-90'])
    
    executeSequence(col_sweep_sequence)
    player.stop()
    player = vlc.MediaPlayer("C:/Users/isaac/Downloads/Robot Sounds/Robot Grabbing.wav")
    player.play()
    time.sleep(0.5)
    blockRetrieved = executeSequence(eating_sequence)
    angle_correction()
    if blockRetrieved:
        if top_entrance:
            executeSequence(['w0-12'])
        else:
            executeSequence(['w0--12','r0-90','w0-12','w0-12'])
        angle_correction()
        return
    
    executeSequence(next_column_sequence)
    executeSequence(col_sweep_sequence)
    player.stop()
    player = vlc.MediaPlayer("C:/Users/isaac/Downloads/Robot Sounds/Robot Grabbing.wav")
    player.play()
    time.sleep(0.5)
    blockRetrieved = executeSequence(eating_sequence)
    if blockRetrieved:
        executeSequence(['r0-90','w0-6'])
        if top_entrance:
            executeSequence(['r0--90'])
        else:
            executeSequence(['r0-90','w0-12'])
        executeSequence(['r0--90','w0-12'])
        angle_correction()
        return

    executeSequence(next_column_sequence)
    executeSequence(col_sweep_sequence)
    player = vlc.MediaPlayer("C:/Users/isaac/Downloads/Robot Sounds/Robot Grabbing.wav")
    player.play()
    executeSequence(eating_sequence)

    if top_entrance:
        executeSequence(['r0-90'])
    else:
        executeSequence(['r0-180'])

    executeSequence(['w0-12','r0-90','w0-12'])
    angle_correction()
    return
    
def transmitNetwork(data):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.connect((HOST, PORT_TX))
            s.send(data.encode('utf-8'))
        except (ConnectionRefusedError, ConnectionResetError):
            print('Tx Connection was refused or reset.')
            _thread.interrupt_main()
        except TimeoutError:
            print('Tx socket timed out.')
            _thread.interrupt_main()
        except EOFError:
            print('\nKeyboardInterrupt triggered. Closing...')
            _thread.interrupt_main()

def receiveNetwork():
    global responses
    global time_rx
    while True:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s2:
            try:
                s2.connect((HOST, PORT_RX))
                response_raw = s2.recv(1024)
                if response_raw:
                    responses = bytes_to_list(response_raw)
                    time_rx = datetime.now().strftime("%H:%M:%S")
            except (ConnectionRefusedError, ConnectionResetError):
                print('Rx connection was refused or reset.')
                _thread.interrupt_main()
            except TimeoutError:
                print('Response not received from robot.')
                _thread.interrupt_main()

def transmitSerial(data):
    SER.write(data.encode('ascii'))

def receiveSerial():
    global responses
    global time_rx

    while True:
        # If responses are ascii characters, use this
        response_raw = (SER.readline().strip().decode('ascii'),)
        # print(1, response_raw)    # debug only

        # If responses are 8 bytes (4-byte floats with 4 bytes of padding 0x00 values after), use this
        # response_raw = bytes_to_list(SER.readline())

        # If response received, save it
        if response_raw[0]:
            # print(2, response_raw[0])     # debug only
            responses = response_raw
            # print(3, responses[0])    # debug only
            time_rx = datetime.now().strftime("%H:%M:%S")

        time.sleep(0.5)

def transmit(data):
    if SIMULATE:
        transmitNetwork(data)
    else:
        transmitSerial(data)

def bytes_to_list(msg):
    if SIMULATE:
        num_responses = int(len(msg)/8)
        data = struct.unpack("%sd" % str(num_responses), msg)
        return data
    else:
        num_responses = int(len(msg)/8)
        if num_responses:
            unpackformat = "<" + num_responses*"f4x"
            data = struct.unpack(unpackformat, msg)
            return data

def orientation_adjust():
    if SIMULATE == False:
        transmit('r0--45')
        interval = 15
    else:
        transmit('r0--45')
        interval = 15
    rxString = ""
    time.sleep(0.5)
    while rxString != math.inf and rxString != "$" and rxString != "#":
        #rxString = receive()
        rxString = responses[0]    # OLD CODE BEFORE IAN'S NEW BLUETOOTH CODE **
        time.sleep(0.5)
    
    sensRecord = []
    sensRecord = sensors(sensRecord) #get readings for all sensors
    print(sensRecord)
    sensRecord_a = [sensRecord[0],sensRecord[1],sensRecord[2],sensRecord[3]]

    min_sensor = sensRecord_a.index(min(sensRecord_a))
    min_sensor_reading = min(sensRecord_a)
    rotation = 0
    rotationangle = 0
    
    if SIMULATE == False:
        while rotation<90:
            transmit('r0-15')
            rxString = ""
            time.sleep(0.5)

            while rxString != math.inf and rxString != "$" and rxString != "#":
                #rxString = receive()
                rxString = responses[0]    # OLD CODE BEFORE IAN'S NEW BLUETOOTH CODE **
                time.sleep(0.5)

            sensRecord = []
            sensRecord = sensors(sensRecord) #get readings for all sensors
            sensRecord_a = [sensRecord[0],sensRecord[1],sensRecord[2],sensRecord[3]]

            for i in range(0, 3):
                if sensRecord_a[i] < min_sensor_reading:
                    min_sensor_reading = sensRecord_a[i]
                    rotationangle = rotation
                    min_sensor = i

            rotation+=interval
        angle_correct = 83 - rotationangle
        output = 'r0--' + str(angle_correct)
        transmit(output)
        rxString = ""
        time.sleep(0.5)

        while rxString != math.inf and rxString != "$" and rxString != "#":
            #rxString = receive()
            rxString = responses[0]    # OLD CODE BEFORE IAN'S NEW BLUETOOTH CODE **
            time.sleep(0.5)
    
    else:
        while rotation<90:
            transmit('r0-15')
            rxString = ""
            time.sleep(0.5)

            while rxString != math.inf and rxString != "$" and rxString != "#":
                #rxString = receive()
                rxString = responses[0]    # OLD CODE BEFORE IAN'S NEW BLUETOOTH CODE **
                time.sleep(0.5)

            sensRecord = []
            sensRecord = sensors(sensRecord) #get readings for all sensors
            sensRecord_a = [sensRecord[0],sensRecord[1],sensRecord[2],sensRecord[3]]

            for i in range(0, 4):
                if sensRecord_a[i] < min_sensor_reading:
                    min_sensor_reading = sensRecord_a[i]
                    rotationangle = rotation
                    min_sensor = i

            rotation+=interval
        angle_correct = 90 - rotationangle - 5
        output = 'r0--' + str(angle_correct)
        transmit(output)
        rxString = ""
        time.sleep(0.5)

        while rxString != math.inf and rxString != "$" and rxString != "#":
            #rxString = receive()
            rxString = responses[0]    # OLD CODE BEFORE IAN'S NEW BLUETOOTH CODE **
            time.sleep(0.5)

def sensors(sensRecord):
    if SIMULATE == True:
        sensorTimeDelay()

        transmit('u0')
        sensorTimeDelay()
        sensRecord.append(round(float(responses[0]),2))       # recording ultrasonic sensor reading from the front sensor

        transmit('u1')
        sensorTimeDelay()
        sensRecord.append(round(float(responses[0]),2))       # recording ultrasonic sensor reading from the right sensor

        transmit('u2')
        sensorTimeDelay()
        sensRecord.append(round(float(responses[0]),2))       # recording ultrasonic sensor reading from the left sensor

        transmit('u3')
        sensorTimeDelay()
        sensRecord.append(round(float(responses[0]),2))       # recording ultrasonic sensor reading from the back sensor
        
        transmit('u4')
        sensorTimeDelay()
        sensRecord.append(round(float(responses[0]),2))       # recording ultrasonic sensor reading from the right 45* sensor
        
        transmit('u5')
        sensorTimeDelay()
        sensRecord.append(round(float(responses[0]),2))       # recording ultrasonic sensor reading from the left 45* sensor
        
        #print(f"Scanned ultrasonic sensors: {sensRecord}")
        return sensRecord       # Array of sensor data is outputted. 
    elif SIMULATE == False:
        transmit('U')
        sensorTimeDelay()
        
        sensRecord = str(responses[0])                # In case ascii characters cannot be interpreted by Python
        time.sleep(0.5)
        print(sensRecord)
        sensRecord = sensRecord.split('/')          # Split the sent strings along the '/'  
        time.sleep(0.5)
        
        while len(sensRecord) != 6:
            transmit('U')
            sensorTimeDelay()      
            sensRecord = str(responses[0])                # In case ascii characters cannot be interpreted by Python
            time.sleep(0.5)
            sensRecord = sensRecord.split('/')          # Split the sent strings along the '/' 
            time.sleep(0.5)
        
        print(sensRecord)
        sensRecord = [float(sensRecord[0]), float(sensRecord[1]), float(sensRecord[2]), float(sensRecord[3]), float(sensRecord[4]), float(sensRecord[4])]
        #print(sensRecord)
        # Line Above assumes x5 sensor readings sent to the robot, 5 element list/array is outputted. 
        return sensRecord

def sensorTimeDelay():
    if SIMULATE:
        time.sleep(0.05)
    else:
        time.sleep(1.75)

def Lin_Move_old(p, heading, lm):
    # Transmit
    movement = 'w0-12'
    cmd, lm = orthog_filter_postLocal(movement, lm)
    transmit(movement)
    rxString = ""
    while rxString != math.inf and rxString != "$" and rxString != "#":
        #rxString = receive()
        rxString = responses[0]    # OLD CODE BEFORE IAN'S NEW BLUETOOTH CODE ****************************************************************************************************************************************
        time.sleep(0.5)


    # Local Movement Update
    p, heading = eng.Localize_2D_move(p, matrix_mask, cmd, heading, nargout=2)
    time.sleep(0.5)

    # Take Sensor Readings
    sensor = []
    sensor = sensors(sensor)            # Update Sensor Readings
    tile_state = Ultra_to_Tile(sensor) 

    # Local Sense Update
    p, rob_x, rob_y, max_p = eng.Localize_2D_sense(p, ultra_world, matrix_mask, tile_state, fig, nargout=4)     # Updating Graph and localization probability
    max_ind = [int(rob_x), int(rob_y)]    # Overwrite Max Index 
    
    return p, heading, max_ind, lm

def Lin_Move(p, heading, lm, max_ind):
    # Transmit
    movement = 'w0-12'
    cmd, lm = orthog_filter_postLocal(movement, lm)
    transmit(movement)
    rxString = ""
    waittime = 0
    while rxString != math.inf and rxString != "$" and rxString != "#" and waittime < 10:
        #rxString = receive()
        rxString = responses[0]    # OLD CODE BEFORE IAN'S NEW BLUETOOTH CODE **
        time.sleep(0.5)
        waittime = waittime+1

    x = max_ind[0]
    y = max_ind[1]

    # Local Movement Update
    if heading == 0:
        x = x
        y = y + 1
    elif heading == 180:
        x = x
        y = y - 1
    elif heading == 90:
        x = x + 1
        y = y 
    elif heading == 270:
        x = x - 1
        y = y 

    max_ind = [x, y]

    return p, heading, max_ind, lm

def Rot_Move_old(p, heading, rotation, lm):
    # Transmit:
    cmd, lm = orthog_filter_postLocal(rotation, lm)
    transmit(rotation)

    rxString = ""
    while rxString != math.inf and rxString != "$" and rxString != "#":
        #rxString = receive()
        rxString = responses[0]    
        time.sleep(0.5)

    # Local Movement Update
    p, heading = eng.Localize_2D_move(p, matrix_mask, cmd, heading, nargout=2)
    time.sleep(0.5)   

    # Take Sensor Readings
    sensor = []
    sensor = sensors(sensor)            # Update Sensor Readings
    tile_state = Ultra_to_Tile(sensor) 

    # Local Sense Update
    p, rob_x, rob_y, max_p = eng.Localize_2D_sense(p, ultra_world, matrix_mask, tile_state, fig, nargout=4)     # Updating Graph and localization probability
    max_ind = [int(rob_x), int(rob_y)]            # Overwrite Max Index 
    
    return p, heading, max_ind, lm

def Rot_Move(p, heading, rotation, lm, max_ind):
    # Transmit:
    cmd, lm = orthog_filter_postLocal(rotation, lm)
    transmit(rotation)

    rxString = ""
    while rxString != math.inf and rxString != "$" and rxString != "#":
        #rxString = receive()
        rxString = responses[0]
        time.sleep(0.5)

    angle = rotation.split('-', 1)
    angle = int(angle[1])     # Pulling Angle

    print(heading)
    if not isinstance(heading, int):
        heading = int(heading[0][0])
    heading = heading - angle
    print(heading)

    if heading < 0:
        heading = heading + 360
    elif heading > 270:
        heading = heading - 360

    return p, heading, max_ind, lm

### Network Setup ###
HOST = '127.0.0.1'  # The server's hostname or IP address
PORT_TX = 61200     # The port used by the *CLIENT* to receive
PORT_RX = 61201     # The port used by the *CLIENT* to send data

### Serial Setup ###
PORT_SERIAL = 'COM4'
BAUDRATE = 9600

# Display text strings
responses = [False]
time_rx = 'Never'

# Create tx and rx threads
if SIMULATE:
    Thread(target = receiveNetwork, daemon = True).start()
else:
    SER = serial.Serial(PORT_SERIAL, BAUDRATE, timeout=0)
    Thread(target = receiveSerial, daemon = True).start()

# Running the robot
RUNNING = True

try:
    # Initialize MATLAB plot, probability matrices, ultrasonic world map, matrix mask, and figure objects
    p, ultra_world, matrix_mask = eng.Initialize_2D_v2(nargout=3)

    p_default = p # Save this for phase 2.5

    # Pull Initial Sensor Readings and tile state
    sensor = []         
    sensor = sensors(sensor)     # Call Robot for Sensor Data
    print(sensor)       # Debug - Array of Sensor Data 
    tile_state = Ultra_to_Tile(sensor) 

    # Initialize Headings
    h1 = matlab.double(0)
    h2 = matlab.double(90)
    h3 = matlab.double(180)
    h4 = matlab.double(270)

    # Initialize All Four Localization Heading Figures
    p1, rob_x, rob_y = eng.preLocalize_2D_sense(p, ultra_world, matrix_mask, tile_state, 1, nargout=3)
    p2, rob_x, rob_y = eng.preLocalize_2D_sense(p, ultra_world, matrix_mask, tile_state, 2, nargout=3)
    p3, rob_x, rob_y = eng.preLocalize_2D_sense(p, ultra_world, matrix_mask, tile_state, 3, nargout=3)
    p4, rob_x, rob_y = eng.preLocalize_2D_sense(p, ultra_world, matrix_mask, tile_state, 4, nargout=3)

    # Initialize Logical Variable For Heading, Max Index Arrays, and iteration variable:
    c1 = c2 = c3 = c4 = 1
    lm1 = lm2 = lm3 = lm4 = 'w0'
    max_ind1 = max_ind2 = max_ind3 = max_ind4 = [rob_x, rob_y]
    i = 0
    drive = True
    fineHeading = 0
    
    # Initialize inout for the specified drop zone:
    drop_zone = input("Please input drop zone (A, B, C, or D): ")
    drop_zone = drop_zone.capitalize()

    # Heading matrix moves to path D by default
    heading_map = [[270, 180, 180,'o','o','x','o','x'],[270, 180, 'o', 'o', 'o', 0, 0, 270],[270, 'o', 'x', 'o', 'o', 90, 'o', 270],[0, 0, 0, 0, 0, 90, 'o', 'x']]

    # Overwriting the routes based on specified dropzone:
    if drop_zone == 'A':
        heading_map[3][2] = 90
    elif drop_zone == 'B':
        heading_map[1][5] = 90
    elif drop_zone == 'C':
        heading_map[1][7] = 90

    # if statements don't trigger - route D assumed inputted
    #----------------------------------------------------------------------------------------------------
    # Stage 1 - Finding The Heading
    
    player = vlc.MediaPlayer("C:/Users/isaac/Downloads/Robot Sounds/Robot Start.wav")
    player.play()
    
    if not SIMULATE:
        orientation_adjust()
        
    while RUNNING:
        # # Obstacle Avoidance/Alignment:   # moved sequence to after pre local robo move
        # angle_correction()
        
        cmd = Pre_Local_Robo_Transmit(drive)

        # Obstacle Avoidance/Alignment: 
        angle_correction()
        
        #### LOCALIZATION CODE BELOW - DO NOT TOUCH ####
        
        # Code below: heading finding 
        if (c1 + c2 + c3 + c4) == 1:
            # If Heading Converges: Carry Over P Matrix, Heading, and fig # to update, then Exit the heading Finder Loop
            if c1 == 1:
                print("Heading Found - Initial Heading = 0")
                [p, h, fig, max_ind, lm] = [p1, h1, 1, max_ind1, lm1]

            elif c2 == 1:
                print("Heading Found - Initial Heading = 90")
                [p, h, fig, max_ind, lm] = [p2, h2, 2, max_ind2, lm2]

            elif c3 == 1:
                print("Heading Found - Initial Heading = 180")
                [p, h, fig, max_ind, lm] = [p3, h3, 3, max_ind3, lm3]

            elif c4 == 1:
                print("Heading Found - Initial Heading = 270")
                [p, h, fig, max_ind, lm] = [p4, h4, 4, max_ind4, lm4]
            
            print('Proceeding to Phase 2')

            # Update matrix with sensor readings before looping
            sensor = sensors(sensor)                        # Call Robot for Sensor Data
            p, h, c, max_ind= Localize_Move_n_Sense(p, h, sensor, 1, cmd, max_ind)
            lm = cmd[0:1]
            break   # Moves to Phase 2 
        
        sensor = []         
        sensor = sensors(sensor)                        # Call Robot for Sensor Data
        #print("Debug: Sensor Readings ", sensor)        # Debug - Array of Sensor Data 

        # Block for iterating Through all 4 possibilities - DO NOT CHANGE THESE TO ELIF, THEY MUST EXECUTE SUCCESSIVELY
        # Heading 0
        if c1 == 1:
            p1, h1, c1, max_ind1= Localize_Move_n_Sense(p1, h1, sensor, 1, cmd, max_ind1)
        # Heading 90
        if c2 == 1:
            p2, h2, c2, max_ind2 = Localize_Move_n_Sense(p2, h2, sensor, 2, cmd, max_ind2)
        # Heading 180
        if c3 == 1:
            p3, h3, c3, max_ind3 = Localize_Move_n_Sense(p3, h3, sensor, 3, cmd, max_ind3)
        # Heading 270
        if c4 == 1:
            p4, h4, c4, max_ind4 = Localize_Move_n_Sense(p4, h4, sensor, 4, cmd, max_ind4) 

        i += 1  # Next iteration
        ####        END OF LOCALIZATION CODE        ####
    
    # Visual transmission for successful localization
    if SIMULATE == False:
        player = vlc.MediaPlayer("C:/Users/isaac/Downloads/Robot Sounds/Robot Localised.wav")
        player.play()
        transmit('C')       # Send Signal to Robot to Indicate Localization
        time.sleep(1)
    else:
        print("Localization complete! Entering Phase 2")
    
    #-----------------------------------------------------------------------------------------------
    # Stage 2 - Moving to LZ
    while RUNNING:
        #print("Running phase 2 code", h, max_ind)   #Debugging line
        
        #cmd = Manual_Input()    # Manual Input is a standin for auto transmission
        
        # Obstacle Avoidance/Alignment: 
        angle_correction()
        
        # Loop for robot to continue moving until at entry position for loading zone
        if (max_ind != [1,3] and max_ind != [3,1]):
            cmd = Pre_Local_Robo_Transmit(drive)
            #sensor = []         
            #sensor = sensors(sensor)                        # Call Robot for Sensor Data
            #print("Debug: Sensor Readings ", sensor)        # Debug - Array of Sensor Data 

            # Localization Update Function with Double Sensor Ping 
            p, h, max_ind, lm = LZ_Move_n_Sense(p, h, fig, cmd, lm)
            print('Debug - p matrix index: ', max_ind)
        
        # Check to see if robot is at entry of loading zone 
        else:
            # checks which of the two entry points the robot is located at, and will orient the heading to point into the loading zone and rewrites the active heading
            if (max_ind == [1,3] and int(h) == 0) or (max_ind == [3,1] and int(h) == 270): 
                cmd = 'r0-180'
                transmit(cmd)               # Rotate
                time.sleep(tempTimeOut)     # Small time delay as required
                p, h, max_ind, lm = LZ_Move_n_Sense(p, h, fig, cmd, lm)     # Update localization if misaligned

            #print('Debug - p matrix index: ', max_ind)

            # Transition point to phase 2.5 - block pickup stage
            if SIMULATE == False:
                transmit('C')   # Send signal to robot
                time.sleep(1)
            else:
                print("Localization complete! Entering Phase 2.5")
            break
        
    #### 2.5 Loop - Find and retreive block ####
    #     # loop for finding and retreiving block
    #     
    if SIMULATE == False:
        findBlock(max_ind)       # function for finding block in loading zone and capturing block
    else:
        artificial_pickup_x = input("Please input artificial pick up location (must be either 1,1 (180, 90), 2,1 (270, 180), 1,2 (0, 90), 2,2 (270, 0)): ")
        artificial_pickup_y = input("Please input artificial pick up location (must be either 1,1 (180, 90), 2,1 (270, 180), 1,2 (0, 90), 2,2 (270, 0)): ")
        artificial_heading = input("Please input artificial heading (must be either 1,1 (180, 90), 2,1 (270, 180), 1,2 (0, 90), 2,2 (270, 0)): ")
        max_ind = [int(artificial_pickup_x), int(artificial_pickup_y)]
        h_python = int(artificial_heading)     
    
    # we do not do this anymore as robot moves to the exit on its own and return is scripted WOOWOWO
    # Reset Probability Matrix and overwrite it with location of robot based on max_ind
    # max_ind = matlab.double(max_ind)
    # p = eng.reset_p(p_default, max_ind, nargout = 1)  # Custom MATLAB function to overwrite probability matrix p based on the max_ind location (I have no idea if this works)
    # h = matlab.double(h_python)

    player = vlc.MediaPlayer("C:/Users/isaac/Downloads/Robot Sounds/Robot Block Pickup.wav")
    player.play()
    transmit('C')           # Visual indicator for captured block
    time.sleep(1)
    
    #-----------------------------------------------------------------------------------------------
    #### Stage 3 - LZ to DZ: ####
    # WE GETTIN OUTTA DA LOADING ZONE WIT THIS ONE :fire_emoji: :fire_emoji: :fire_emoji: :fire_emoji: 
    # Initial Sensor Reading and Update
    # NOTES:
    # variable "lm" - last move: is used to record whether the last move was a rotation or forward movement (r0, or w0)
    #     > This is done to avoid localization drift
    #     > drift prevention accomplished using function: "orthog_filter_post_local()"
    #     > if the last move was a rotation, move w9 in the histogram instead of w12 (offsets the matrix shenanigans associated with orthogonal rotations)
    #     > This is not implemented in the original "orthog_filter" to help with heading convergence



    # time.sleep(0.5)
    # sensor = sensors(sensor)
    # time.sleep(0.5)
    # tile_state = Ultra_to_Tile(sensor) 
    # time.sleep(0.5)
    # p, rob_x, rob_y, max_p = eng.Localize_2D_sense(p, ultra_world, matrix_mask, tile_state, fig, nargout=4)     # Updating Graph and localization probability
    # max_ind = [int(rob_x), int(rob_y)]    # Overwrite Max Index 

    # while RUNNING:
    #     [x, y] = [max_ind[0]-1, max_ind[1]-1]       # MATLAB => Python Index
    #     h_setpoint = heading_map[x][y]              # Index Scripted Heading from Head Map
    #     try:
    #         h_diff = int(h_python) - h_setpoint                     # See how much diff the setpoint heading is vs measured heading
    #         h_diff = int(h_diff)
    #         print(h_diff)
    #     except:
    #         if h_setpoint == 'x':
    #             print("Arrived at Drop Zone ", drop_zone)
    #             print("Transitioning to Stage 4 - Block Removal")
    #             break
    #         else:
    #             print("there was an error! ")

    #     if h == h_setpoint:
    #         p, h, max_ind, lm = Lin_Move(p, h, lm, max_ind)  # Move 12" forward and Update Localization map

    #     # Right Turn / 90 deg CW Rotation
    #     elif h_diff == 90 or h_diff == -270:
    #         p, h, max_ind, lm = Rot_Move(p, h, 'r0-90', lm, max_ind)    
    #         # transmit('r0--90')
    #         p, h, max_ind, lm = Lin_Move(p, h, lm, max_ind)
    #         # transmit('w0-12')   # Move forward

    #     elif h_diff == -90 or h_diff == 270:
    #         p, h, max_ind, lm = Rot_Move(p, h, 'r0--90', lm, max_ind)    
    #         # transmit('r0--90')
    #         p, h, max_ind, lm = Lin_Move(p, h, lm, max_ind)
    #         # transmit('w0-12')   # Move forward

    #     elif abs(h_diff) == 180:
    #         p, h, max_ind, lm = Rot_Move(p, h, 'r0-180', lm, max_ind)    
    #         # transmit('r0--90')
    #         p, h, max_ind, lm = Lin_Move(p, h, lm, max_ind)
    #         # transmit('w0-12')   # Move forward
    
    def exitSequence(instructions):
        for command in instructions:
            transmit(command)
            time.sleep(5)
        return
    time.sleep(4)
    player.stop()
    player = vlc.MediaPlayer("C:/Users/isaac/Downloads/Robot Sounds/Robot Exit Background 1.wav")
    player.play()
    time.sleep(0.5)
    exitSequence(['w0-12'])
    #angle_correction()
    exitSequence(['r0--90','w0-12','w0-12'])
    if drop_zone == 'A':
        exitSequence(['r0--90','w0-12']) #going into A
    else:
        exitSequence(['w0-12','w0-12','w0-12'])
        #angle_correction()
        exitSequence(['r0--90','w0-12','w0-12'])
        if drop_zone == 'B':
            exitSequence(['w0-12']) #going into B
        else:
            exitSequence(['r0-90','w0-12'])
            #angle_correction()
            exitSequence(['w0-12'])
            if drop_zone == 'C':
                exitSequence(['r0--90','w0-12']) #going into C
            else:
                exitSequence(['r0-90','w0-12','w0-12']) #eventually end up in D



    #### Stage 4 block removal ####
    # epic gaming
    # brain broken 2023
    # seagull noises
    # drop off the block and leave
    transmit('w0--2')
    time.sleep(0.5)
    transmit('opn')
    time.sleep(0.5)
    player.stop()
    player = vlc.MediaPlayer("C:/Users/isaac/Downloads/Robot Sounds/Robot Dropoff.wav")
    player.play()
    transmit('w0--8')
    time.sleep(0.5)
    transmit('cls')
    time.sleep(2)
    player.stop()
    player = vlc.MediaPlayer("C:/Users/isaac/Downloads/Robot Sounds/Robot Program Complete.wav")
    player.play()
    transmit('C')
    time.sleep(1)
    transmit('r0-720')
    time.sleep(5)

except KeyboardInterrupt:
    pygame.quit()
    quit()
