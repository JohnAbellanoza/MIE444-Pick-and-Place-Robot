function [p, x1, y1, max] = Localize_2D_sense(p, ultra, M, m_u, fig);
% provide measurements

%sensor update
p = sense_u(ultra, M, p, m_u);

% Finding index of max probability:

[mx,ind]=maxk(p(:),2);

% Largest Number and its index
max = mx(1);
[x1,y1]=ind2sub(size(p),ind(1));

% Decrease Indexing Resolution fro 32x64 to 4x8:
x1 = floorDiv(x1, 4);
y1 = floorDiv(y1, 4);

% test this later:
%x1 = floorDiv(x1-1, 4);
%y1 = floorDiv(y1-1, 4);

% Compute the below after the above floor division is done - should work
%indx_1 = x1*4 + 1;
%indx_2 = indx_1 + 3;
%indy_1 = x1*4 + 1;
%indy_2 = indy_1 + 3;

%b = p(indx_1:indx_2, indy_1: indy_2);
%max = mean(b, 'all');

% Add ifstatement to throw an impossible index at the output if the average
% vs mode of the b matrix is horribly off (Testing Required)

x1 = x1+1;
y1 = y1+1;

% Second Largest Number and its index
% max2 = mx(2);
% [x2,y2]=ind2sub(size(p),ind(2));
% 
% [max_value,idx]=max(p(:));
% [x,y]=ind2sub(size(p),idx);

% Call for Specific Figure and Update Visualizer
fig = double(fig);      % Convert Python integer to matlab usable numbers:
figure(fig);
imagesc(p);

end
