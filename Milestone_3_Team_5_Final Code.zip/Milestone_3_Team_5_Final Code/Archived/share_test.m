function share_test(p)
p
a = p'

end