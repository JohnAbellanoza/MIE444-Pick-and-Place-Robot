import matlab.engine
# MATLAb file must have the following line: matlab.engine.shareEngine('Engine_1')
# =====================================
# Remarks:
# - Called MATLAB functions must have "nargout=1" as the last argument to allow for x1 output for probability array p
# =====================================

# code to startup share session code?

names = matlab.engine.find_matlab()     # Line for finding available shared sessions
print(names)
eng = matlab.engine.connect_matlab()    # Line for connecting to shared MATLAB sessions

# mimic external measurements and movements
m_u = [ 3,  3,  3,  1,  1,  1,  1,  5,  5,  5,  5,  0,  0,  0,  0,  5,  5,  5,  5,  2,  2,  2,  2,  2,  2]
m_m = ["w",'w','w','d','a','d','w','w','w','w','w','w','w','w','w','w','w','w','w','w','d','w','w','w','a']
length = len(m_u)

p, ultra_world, matrix_mask = eng.Initialize_2D(nargout=3)        # Run initial graph generation script - pull initial probability p as a MATLAB vector 
# First script: "Initialize_2D.m"

heading = matlab.double(270)   # initialize heading (assume going down)

# Loop for going through measurements - code below can be integrated in main carefully
for k in range(length):
    sensor_reading = m_u[k]        # index kth reading
    robot_move = m_m[k]
    j = k + 1                       # index variable for histogram (MATLAB starts index at 1, Python starts index at 0)
    
    # Update probability based on sensor readings
    p = eng.Localize_2D_sense(p, ultra_world, matrix_mask, sensor_reading, j, nargout=1)     # Updating Graph and localization probability
    # Second script: "Localize_2D.m"

    p, heading = eng.Localize_2D_move(p, matrix_mask, robot_move, heading, nargout=2)     # Updating Graph and localization probability

# Terminate MATLAB Engine Connection
eng.quit()

