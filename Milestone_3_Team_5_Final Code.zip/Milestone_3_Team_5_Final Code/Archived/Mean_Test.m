A = [1 1 1 1; 2 2 2 2; 2 2 2 2; 1 1 1 1]

b = A(3:4, 3:4)

mean(b, "all")

x1 = 16

x1 = floorDiv(x1, 4)