figure(1);
figure(2);


p = [1, 2, 3, 4;
    4, 2, 4, 1;
    8, 9, 3, 7;
    0, 1, 7, 8];

q = p';


test(1, p);

test(2, q);

function test(fig, a);
    figure(fig);
    imagesc(a);
end




