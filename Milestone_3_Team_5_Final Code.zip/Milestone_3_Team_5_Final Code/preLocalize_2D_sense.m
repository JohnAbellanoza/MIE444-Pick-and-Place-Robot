function [p, x1, y1] = preLocalize_2D_sense(p, ultra, M, sensor, fig);

% sensor update
p = sense_u(ultra, M, p, sensor);

% Finding index of max probability:

[mx,ind]=maxk(p(:),2);

% Largest Number and its index
max1 = mx(1);
[x1,y1]=ind2sub(size(p),ind(1));

% Decrease Indexing Resolution fro 32x64 to 4x8:
x1 = floorDiv(x1, 4) + 1;
y1 = floorDiv(y1, 4) + 1;

% Second Largest Number and its index
%max2 = mx(2);
%[x2,y2]=ind2sub(size(p),ind(2));

%[max_value,idx]=max(p(:));
%[x,y]=ind2sub(size(p),idx);

% Call for Specific Figure and Update Visualizer
fig = double(fig);      % Convert Python integer to matlab usable numbers:
figure(fig);
imagesc(p);

end
