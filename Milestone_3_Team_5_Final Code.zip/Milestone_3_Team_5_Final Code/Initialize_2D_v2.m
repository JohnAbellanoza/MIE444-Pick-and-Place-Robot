function [p, ultra, M] = Initialize_2D_v2()
% Milestone 3 Notes:
%    - have a string input for the figure number
%    - Modify initialize, sense, and move to have the figure number as an input
%    - Modify Sense and Move to Specifically update the currently inputted
%    figure
%    - Modify Python to move the diff probability matrices around for each
%    diff heading
%
% Map Generation below
%initalization of the world
dim1 = 32; dim2 = 16; 
locationindex = reshape(1:dim1*dim2,dim1,dim2)'; 
n = numel(locationindex);
rand('twister',5489);
bw = reshape(randi([0 1],n,1),dim2,dim1); %0 = black, 1 = white

%make blocks
M = zeros(size(bw));
Blocks = [2, 3; 3, 2; 4, 3; 5, 1; 5, 3; 7, 1; 7, 3; 7, 4;];
for xx = 1:size(Blocks,1),
	x = Blocks(xx,1); y = Blocks(xx,2);
	M(1+(y-1)*4:(y-1)*4+4, 1+(x-1)*4:(x-1)*4+4) = 1;
end
M = [ones(dim2,1) M ones(dim2,1)];
M = [ones(1, dim1+2); M; ones(1, dim1+2)];  % Matrix of max map consisting of 1's and 0's in 3" resolution

%generate ultrasonic world

ultra = zeros(size(bw));

for sec_row = 1:4:dim2,
    for sec_col = 1:4:dim1,
        segRow = M(sec_row+2, sec_col:sec_col+5);
        segCol = M(sec_row:sec_row+5, sec_col+2);
        val = sum(segRow)+sum(segCol);
        if val == 2 && sum(segRow)~=1,
            val = 5;
        end
        ultra(sec_row:sec_row+3, sec_col:sec_col+3) = val;  
    end
end

% create mask for blocks
M = abs(M-1);
M = M(2:end-1, 2:end-1);
% figure; imagesc((bw+1).*M); colormap(gray);

% initialize probability matrix and output it 
% Aside - Python is able to read this as a MATLAB double 

p = ones(dim2,dim1)*(1/n);  % dim2 x dim1 matrix full of elements equal to 1/512 (Small Number) 

% Initialize Figures 1 through 4 and output them
f1 = figure(1);
f2 = figure(2);
f3 = figure(3);
f4 = figure(4);
%figure_number = figure;     % Deploys initial heatmap visualizer
end