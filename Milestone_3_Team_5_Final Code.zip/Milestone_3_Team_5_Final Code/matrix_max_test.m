A = [11 15; 16 99 ; 87 100];
% 
[mx,ind]=maxk(A(:),2)

% Largest Number and its index
max1 = mx(1)
[x1,y1]=ind2sub(size(A),ind(1))

% Second Largest Number and its index
max2 = mx(2)
[x2,y2]=ind2sub(size(A),ind(2))

